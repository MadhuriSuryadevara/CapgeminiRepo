package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.TestService;

@RestController
@RequestMapping("/technicianrole")
@CrossOrigin(origins="http://localhost:4200")

public class TestController {
	Integer totalPrice=0;
	@Autowired
	TestService technicianRoleService;
	
	Logger logger=LoggerFactory.getLogger(UserRegistrationController.class);
	
	
	@PostMapping("/addtests")
	public Test addTests(@RequestBody Test testDetails) {
		logger.info("adding the new tests");
		return technicianRoleService.addTest(testDetails);
	}
	
	@PutMapping("/updatetests/{testId}/{price}")
	public void updateTests(@PathVariable("testId") Long testId,@PathVariable("price") Integer testPrice ) {
		logger.info("updating the new tests");
		technicianRoleService.updateTest(testId, testPrice);
	}
	
	@GetMapping("/getalltests")
	public List<Test> getAllTests(){
		return technicianRoleService.getAllTests();
	}
		
	
@DeleteMapping("/deletetests/{id}")
public void deleteTests(@PathVariable("id") Long id) {
	System.out.println("delete test controller"+id);
	logger.info("in deleting tests method");
	technicianRoleService.deleteTest(id);
}
@GetMapping("/get/{cmail}/{price}")
public Integer getPrice(@PathVariable("cmail") String cmail,@PathVariable("price") Integer price) {
	System.out.println("in get price controller"+cmail+price);
	return technicianRoleService.getPrice(cmail, price);
}
@GetMapping("/setprice/{cmail}")
	public void setprice(@PathVariable("cmail") String cmail) {
	logger.info("setting total price to 0 ");
		technicianRoleService.setprice(cmail);
	}
@GetMapping("/gettestbyname/{name}")
public List<Test> getTestByName(@PathVariable("name") String name){
	return technicianRoleService.getTestByName(name);
}

}
