package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.TechnicianDao;
import com.cg.healthcarelogistics.dto.Technician;
import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;

@Service
public class TechnicianServiceImpl implements TechnicianService{

	@Autowired
	TechnicianDao managerDao;
	@Override
	public Technician addTechnician(Technician managerRole) {
		// TODO Auto-generated method stub
		return managerDao.addTechnician(managerRole);
	}

	@Override
	public List<Technician> getAllTechnician() {
		// TODO Auto-generated method stub
		return managerDao.getAllTechnician();
	}

	@Override
	public void updateTechnician(Long mobile, Integer salary, Integer experience) {
		// TODO Auto-generated method stub
		managerDao.updateTechnician(mobile, salary, experience);
		
	}

	@Override
	public void deleteTechnician(Long mobileNo) {
		// TODO Auto-generated method stub
		managerDao.deleteTechnician(mobileNo);
		
	}

	@Override
	public boolean getTechnicianDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		return managerDao.getTechnicianDetails(mobile, password);
	}

	@Override
	public Technician getById(Long mobileNo) {
		// TODO Auto-generated method stub
		return managerDao.getById(mobileNo);
	}

	@Override
	public List<Technician> getTechnicianByName(String name) {
		// TODO Auto-generated method stub
		return managerDao.getTechnicianByName(name);
	}

	
	

	
	
	
	
	

}
