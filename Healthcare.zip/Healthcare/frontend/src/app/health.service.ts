import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable, Subject, concat} from 'node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class HealthService {
  currentTestId:number=0;
  
  
  
currentUser:number=0;
currentUserMailId:String="";
technicianMail:String="";
  
  data3:any=[];
  data4:any=[];
  customers: Observable<Object>;
  result:string;
  constructor(private http:HttpClient) { }
  
  addUserRegister(data:any){
    console.log("service"+data)
    let userinput={"mobileNo":data.mobile,
    "userName":data.username,
     "gender":data.gender,
     "email":data.email,
    "role":data.role,
   "password":data.password,
   "dob":data.dob
   
}
console.log("adduser service");
   console.log(data.mobile);
   
    return this.http.post("http://localhost:9920/userregister/adduser",userinput);
  }

  checkMobile(mobile:number,pwd:String){
    console.log("In service");
    console.log("in service mobile is "+mobile);
    console.log("in service password"+pwd);
    return this.http.get("http://localhost:9920/userregister/validatemobile/"+mobile+"/"+pwd);


  }

  addTest(data:any){
    let input={"testId":data.id,
    "testName":data.name,
    "testPrice":data.price,
    "testDescription":data.desc}
    console.log("in health service"+data.price)
    return this.http.post("http://localhost:9920/technicianrole/addtests",input);

};

deleteTests(data:any){

  return this.http.delete("http://localhost:9920/technicianrole/deletetests/"+data);
}
addTechnician(data:any){
  let input1={
    "mobileNo":data.mobile,
    "technicianName":data.name,
    "salary":data.salary,
    "gender":data.gender,
    "experience":data.experience,
    "technicianDescription":data.desc,
    "password":data.password,
    "technicianEmail":data.email
  }
  console.log("in health service technician"+data.desc)
  return this.http.post("http://localhost:9920/managercontrol/addtechnician",input1);
}
getAllTechnician()
{
  return this.http.get("http://localhost:9920/managercontrol/getalltechnician");
}
deleteTechnician(data:any)
{
return this.http.delete("http://localhost:9920/managercontrol/deletetechnician/"+data)
}
acceptOrReject(){
let results = localStorage.getItem("result");
// let email = localStorage.getItem("email");

console.log(results);
if(results=="true"){
  alert("Accepted");


}
else if(results=="false"){
  alert("Rejected")
}
}


getAllTests(){
  return this.http.get("http://localhost:9920/technicianrole/getalltests");
}
getAllRoleDetails(mobile:number,password:string){
  console.log("in service role details"+mobile);
  return this.http.post("http://localhost:9920/userregister/getroledetails/"+mobile+"/"+password,+mobile+password);
}

getTechnicianDetails(mobile:number,password:string){
  console.log("in technician details service"+mobile);
  return this.http.get("http://localhost:9920/managercontrol/getroledetails/"+mobile+"/"+password);

}
getMobile(mobile){
  console.log("in service getMobile method"+mobile);
 this.http.get("http://localhost:9920/userregister/getUserMobile/"+mobile);
 this.data3 = this.http.get("http://localhost:9920/userregister/getUserMobile/"+mobile);
 console.log('in service'+this.data3.userName)
  return this.data3;
}


setDetails(data)
{
 this.data4=data;
 console.log("setting details"+this.data4.password);
}
getAllDetails(){
  console.log("for technician ,in service"+this.data4);
  return this.data4;
}
updateTests(id:number,price:number){
  console.log("in update service"+id);
  console.log("in update service"+price);
 return this.http.put("http://localhost:9920/technicianrole/updatetests/"+id+"/"+price,+id);
}
addBooking(umail: String,tmail: String) {
  console.log("adding booking")
  console.log("user mail:"+umail);
  console.log("technician mail is:"+tmail)
  return this.http.get("http://localhost:9920/userregister/booking/"+umail+"/"+tmail);
   
}
getBookedUsers(technicianMail: String) {
  console.log("getting booked users")
  console.log("in service booking"+technicianMail);
  return this.http.get("http://localhost:9920/userregister/getdetails/"+technicianMail);

}

gettechnicianById(mobile:string){
  return this.http.get("http://localhost:9920/managercontrol/getbyid/"+mobile);
}
getPrice(mail:string,price:number){
  return this.http.get("http://localhost:9920/technicianrole/get/"+mail+"/"+price);
}
setTotalPricetoZero(mail){
  return this.http.get("http://localhost:9920/technicianrole/setprice/"+mail)
}
displayStatus(mobile:number){
  return this.http.get("http://localhost:9920/userregister/getstatus/"+mobile);
}
}

