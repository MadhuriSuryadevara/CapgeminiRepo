import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './health/home.component';
import { ManagerComponent } from './health/manager.component';
import { TechnicianComponent } from './health/technician.component';
import { CustomerComponent } from './health/customer.component';
import { LogoutComponent } from './health/logout.component';
import { RegisterComponent } from './health/register.component';
import {HttpClientModule} from '@angular/common/http';
import { ManageroperationsComponent } from './health/manageroperations.component';
import { ManagertestComponent } from './health/managertest.component';
import { ManagertechnicianComponent } from './health/managertechnician.component';
import { CustomeroperationsComponent } from './health/customeroperations.component';
//import { TechnicianoperationsComponent } from './health/technicianoperations.component';
import { TechnicianacceptrejectComponent } from './health/technicianacceptreject.component';
import { CustomertestbookingComponent } from './health/customertestbooking.component';
import { CustomerviewtestsComponent } from './health/customerviewtests.component';
import { ManagerviewtechnicianComponent } from './health/managerviewtechnician.component';
import { ManagerdeletetechnicianComponent } from './health/managerdeletetechnician.component';
import { ManagerviewtestsComponent } from './health/managerviewtests.component';
import { ManagerdeletetestsComponent } from './health/managerdeletetests.component';
import { UpdatetestsComponent } from './health/updatetests.component';
import { ManagerupdatetestsComponent } from './health/managerupdatetests.component';


import {DataTableModule} from "angular-6-datatable";


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ManagerComponent,
    TechnicianComponent,
    CustomerComponent,
    LogoutComponent,
    RegisterComponent,
    ManageroperationsComponent,
    ManagertestComponent,
    ManagertechnicianComponent,
    CustomeroperationsComponent,
    TechnicianacceptrejectComponent,
    CustomertestbookingComponent,
    CustomerviewtestsComponent,
    ManagerviewtechnicianComponent,
    ManagerdeletetechnicianComponent,
    ManagerviewtestsComponent,
    ManagerdeletetestsComponent,
    UpdatetestsComponent,
    ManagerupdatetestsComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    DataTableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
