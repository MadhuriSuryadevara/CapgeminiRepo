package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.TestDao;
import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;

@Service
public class TestServiceImpl implements TestService {
@Autowired
TestDao technicianRoleDao;
	@Override
	public Test addTest(Test test) {
		// TODO Auto-generated method stub
		System.out.println("in service"+test);
		return technicianRoleDao.addTest(test);
	}

	@Override
	public void updateTest(Long testId, Integer price) {
		// TODO Auto-generated method stub
		technicianRoleDao.updateTest(testId, price);
		
	}

	@Override
	public List<Test> getAllTests() {
		// TODO Auto-generated method stub
		return technicianRoleDao.getAllTests();
	}


	

	@Override
	public void deleteTest(Long testId) {
		// TODO Auto-generated method stub
		technicianRoleDao.deleteTest(testId);
	}

	/*@Override
	public void billing(String cmail, Integer testPrice) {
		// TODO Auto-generated method stub
		 technicianRoleDao.billing(cmail,testPrice);
	}*/

	@Override
	public Integer getPrice(String cmail, Integer price) {
		// TODO Auto-generated method stub
		return technicianRoleDao.getPrice(cmail, price);
	}

	@Override
	public void setprice(String cmail) {
		// TODO Auto-generated method stub
		technicianRoleDao.setprice(cmail);
	}

	
	
	

}
