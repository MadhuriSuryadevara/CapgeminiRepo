package com.cg.healthcarelogistics.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="technicians_operations")
public class Test {
	@Id
	@Indexed(name="_id")
	private Long testId;
	private String testName;
	private Integer testPrice;
	private String testDescription;
	
	public Long getTestId() {
		return testId;
	}
	public void setTestId(Long testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public Integer getTestPrice() {
		return testPrice;
	}
	public void setTestPrice(Integer testPrice) {
		this.testPrice = testPrice;
	}
	public String getTestDescription() {
		return testDescription;
	}
	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}
		
	public Test(Long testId, String testName, Integer testPrice, String testDescription) {
		super();
		this.testId = testId;
		this.testName = testName;
		this.testPrice = testPrice;
		this.testDescription = testDescription;
	}
	public Test() {
		
	}
	@Override
	public String toString() {
		return "TechnicianRole [testId=" + testId + ", testName=" + testName + ", testPrice=" + testPrice
				+ ", testDescription=" + testDescription + "]";
	}
	
	
	

}
