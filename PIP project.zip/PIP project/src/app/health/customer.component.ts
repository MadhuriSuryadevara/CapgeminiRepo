import { Component, OnInit, Input } from '@angular/core';
import { HealthService } from '../health.service';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
message:boolean=false;
  mobile:number;
password:any;
email:any;
result:any;
@Input() data1:any=[];
@Input() data10:String="anu";
result1:any=[];
  constructor(private service:HealthService,private router:Router) { }
  check(mobile,password,mail){
    console.log("customer mail is"+mail);
    localStorage.setItem("mail",mail);
    console.log("mobile and password is"+mobile+password)
    this.service.getMobile(mobile).subscribe(result1=>{
      this.data1=result1;
    console.log("checking user mobile"+this.data1.mobileNo)
    /* this.service.setDetails(this.data1); */
    this.service.sendData(this.data1);
    this.service.setDetails(this.data1);
    this.service.gettingData("good afternoon");
    console.log("initially"+this.service.currentUser);
    this.service.currentUser=this.data1.mobileNo;
    console.log("checking current user"+ this.service.currentUser)
    console.log("checking emailid"+this.data1.email);
    this.service.currentUserMailId=this.data1.email;
    console.log("finally"+this.service.currentUserMailId);
    

   
  });
    
    this.service.getAllRoleDetails(mobile,password).subscribe(data=>{
      this.result=data;
      if(this.result==3)
      {
        this.router.navigate(['/customerviewtests'])

        /* this.router.navigate(['/customertestbooking']) */
      }
    
      else {
       this.message=true;
      }

    });
  }
  


  ngOnInit() {

 
  }

}
