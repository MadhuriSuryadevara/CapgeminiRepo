import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerviewtechnician',
  templateUrl: './managerviewtechnician.component.html',
  styleUrls: ['./managerviewtechnician.component.css']
})
export class ManagerviewtechnicianComponent implements OnInit {
  data:any=[];
  result:any=[];
  constructor(private router:Router,private service:HealthService) { }

addTechnician(){

  this.router.navigate(['/managertechnician'])
}
deleteTechnician(mobile:any){
  
  console.log("in delete technician ts file"+mobile);
 /* let index=this.data.indexOf(mobile);
  this.data.splice(index,1);  */
    this.service.deleteTechnician(mobile).subscribe();
  
  }
  
getAllTechnician()
{
  this.service.getAllTechnician().subscribe(result=>{this.data=result;
    console.log("in manager delete technician"+this.data);
  
})
}
ngOnInit() {
  this.service.getAllTechnician().subscribe(result=>{this.data=result;
    console.log("data"+this.data)});

}
}
