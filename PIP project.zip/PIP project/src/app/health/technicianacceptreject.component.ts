import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technicianacceptreject',
  templateUrl: './technicianacceptreject.component.html',
  styleUrls: ['./technicianacceptreject.component.css']
})
export class TechnicianacceptrejectComponent implements OnInit {
  result1:any=[];
  data:any=[];
  val1:any=[];
  mob:number;
  userName: string;
  acceptmessage:boolean=false;
  rejectmessage:boolean=false;
  messaging:boolean=false;

  constructor(private service:HealthService,private router:Router) { }

acceptBooking(){
  console.log("in technician")
  
  
}

accept(){
  
  this.userName="true";
  localStorage.setItem("result", this.userName)
 this.acceptmessage=true; 
this.messaging=true;
  // localStorage.setItem("email", email)
  /* alert("Accepted"); */
}

reject(){
   this.userName="false";
   localStorage.setItem("result", this.userName)
   this.messaging=true;
 this.rejectmessage=true;
  //  localStorage.setItem("email", email)

  /* alert("Rejected"); */

}
Logout(){
  this.router.navigate(['/home'])
}

  ngOnInit() {
    
     console.log("getting details in technician"+this.service.getBookedUsers(this.service.technicianMail))
      return this.service.getBookedUsers(this.service.technicianMail).subscribe((result1:any)=>{
        this.val1=result1;
      })
      }
    }
    
    



