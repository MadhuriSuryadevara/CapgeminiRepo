import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private service:HealthService) { }
model:any={}
result:boolean=false;
addUser():any{
  this.result=true;
  this.service.addUserRegister(this.model).subscribe();
}
  ngOnInit() {
  }

}
