import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerdeletetests',
  templateUrl: './managerdeletetests.component.html',
  styleUrls: ['./managerdeletetests.component.css']
})
export class ManagerdeletetestsComponent implements OnInit {
data:any=[];
result:any=[];

  constructor(private service:HealthService) { }
deleteTests(id:any){
  
console.log("in delete tests ts file"+id);
let index=this.data.indexOf(id);
this.data.splice(index,1);
  this.service.deleteTests(id).subscribe();

}
getAllTests(){
  this.service.getAllTests().subscribe(result=>{this.data=result;
    console.log("in manager delete tests"+this.data);
  })
  

}

  ngOnInit() {
    this.service.getAllTests().subscribe(result=>{this.data=result;
      console.log("data"+this.data.test)});
  }

}
