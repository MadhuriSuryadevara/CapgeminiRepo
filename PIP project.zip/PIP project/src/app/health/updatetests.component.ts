import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-updatetests',
  templateUrl: './updatetests.component.html',
  styleUrls: ['./updatetests.component.css']
})
export class UpdatetestsComponent implements OnInit {

  constructor(private service:HealthService) { }
model:any={};
id:number;
price:number;
testId:number;
show:boolean=false;

  updateTest(){
  console.log("in ts file"+this.id)
  this.show=true;
    
  this.service.updateTests(this.testId,this.price).subscribe();
  
}
  ngOnInit() {
    this.testId=this.service.currentTestId;
  }

}
