package com.cg.healthcarelogistics.dao;

import java.util.List;

import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TestDao {
	public Test addTest(Test test);
	public void updateTest(Long testId,Integer price);
	public List<Test> getAllTests();
	public void deleteTest(Long testId);
	/*public void billing(String cmail,Integer testPrice);*/
	public Integer getPrice(String cmail,Integer price);
	public void setprice(String cmail);
		
	
}
