package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.UserRegistrationService;

@RestController
@RequestMapping("/userregister")
@CrossOrigin(origins="http://localhost:4200")
public class UserRegistrationController {
	@Autowired
	UserRegistrationService userRegistrationService;
	
	@GetMapping("/validatemobile/{mob}/{password}")
	public boolean validateMobile(@PathVariable("mob") Long mobile,@PathVariable("password")String password) {
		System.out.println("anushaaaaaaaaaaaaaaaarrrr");
		return userRegistrationService.validateUserLogin(mobile,password);
	}
	
	@PostMapping("/adduser")
	public UserRegistration addUser(@RequestBody UserRegistration user) {
		System.out.println("in controller"+user);
		return userRegistrationService.addUser(user);
	}
		
	@PostMapping("/getroledetails/{mobile}/{password}")
	public Integer getRoleDetails(@PathVariable("mobile") Long mob,@PathVariable("password") String pwd) {
		String role=userRegistrationService.getDetailsBasedOnRole(mob, pwd);
		System.out.println("in conroller roles"+role);
		if(role.equalsIgnoreCase("manager")){
			return 1;
			
		}
		else if(role.equalsIgnoreCase("technician")) {
			return 2;
			
		}
		
			
		else if(role.equalsIgnoreCase("customer")){
			return 3;
		}
				return 4;
	}
		
		
		
	
	@GetMapping("/getalluser")
	public List<UserRegistration> getAllUserDetails(){
		return userRegistrationService.getAllUserDetails();
	}
	
	@GetMapping("/getUserMobile/{mobile}")
	public UserRegistration getUserMobile(@PathVariable("mobile") Long mobile) {
		System.out.println("final result "+userRegistrationService.getUserMobile(mobile));
		return userRegistrationService.getUserMobile(mobile);
	}
	@PostMapping("/booking/{umail}/{tmail}")
	public String booking(@PathVariable("umail") String umail,@PathVariable("tmail") String tmail) {
		System.out.println("in booking controller");
		System.out.println("booking controller"+umail+tmail);
		int i=userRegistrationService.booking(umail, tmail);
		if(i==1) {
			return "success";
		}
		else {
			return "unsuccess";
		}
	}
	@GetMapping("/booking/{umail}/{tmail}")
	public Integer booking1(@PathVariable("umail") String umail,@PathVariable String tmail) {
		
		System.out.println("hkheukwhuk");
		return userRegistrationService.booking(umail, tmail);
		
	}
	
	@GetMapping("/getdetails/{tmail}")
		public List<UserRegistration> getdetails(@PathVariable("tmail") String tmail){
			return userRegistrationService.getDetails(tmail);
		}
	@DeleteMapping("/delete/{mobile}")
	public void delete(@PathVariable("mobile") Long mobile){
		userRegistrationService.delete(mobile);
	}
	
	
	
}


