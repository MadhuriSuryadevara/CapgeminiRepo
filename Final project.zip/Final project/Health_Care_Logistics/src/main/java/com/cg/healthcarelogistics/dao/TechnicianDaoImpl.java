package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.healthcarelogistics.dto.Technician;
import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.mongodb.Mongo;

@Repository
public class TechnicianDaoImpl implements TechnicianDao {
	@Autowired
	MongoTemplate mongotemplate;
	// method for adding the new technician
	@Override
	public Technician addTechnician(Technician managerRole) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(managerRole);
	}
	// method for fetching all the technicians 
	@Override
	public List<Technician> getAllTechnician() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(Technician.class) ;
	}
	
	// method for updating salary and experience of technician based on technicianId 
	@Override
	public void updateTechnician(Long mobile,Integer salary, Integer experience) {
		// TODO Auto-generated method stub
		List<Technician> technicianDetails=mongotemplate.findAll(Technician.class);
		for(Technician data:technicianDetails) {
			if(data.getMobileNo().equals(mobile)) {
				data.setSalary(salary);
				data.setExperience(experience);
				mongotemplate.save(data);
			}
		}
		
	}
	// method for deleting the technicians based on testyId
	@Override
	public void deleteTechnician(Long mobileNo) {
		// TODO Auto-generated method stub
		List<Technician> data3=mongotemplate.findAll(Technician.class);
		for(Technician data4:data3) {
			if(data4.getMobileNo().equals(mobileNo)) {
				mongotemplate.remove(data4);
			}
		}
		
		
	}
	// method for validating the credentials of technician
	@Override
	public boolean getTechnicianDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		boolean valid=false;
		System.out.println("in dao roles details"+mobile+password);
	
		List<Technician> details=mongotemplate.findAll(Technician.class);
		for(Technician technicianDetails:details) {
		if(technicianDetails.getMobileNo().equals(mobile)) {
				if(technicianDetails.getPassword().equals(password)) {
				valid=true;
				
				}
			}
		}
		return valid;
	}
	
	

	// method for fetching particular technician
	@Override
	public Technician getById(Long mobileNo) {
		// TODO Auto-generated method stub
		List<Technician> data4=mongotemplate.findAll(Technician.class);
		for(Technician details:data4) {
			if(details.getMobileNo().equals(mobileNo)) {
				return details;
			}
		}
		return null;
		
	}

	

	
	



}
