import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-managertest',
  templateUrl: './managertest.component.html',
  styleUrls: ['./managertest.component.css']
})
export class ManagertestComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
  model:any={};
  result:boolean=false;
  /* Method for adding new test */
  addTest()
  {

    console.log("in ts file"+this.model)
    this.result=true;
    
    this.service.addTest(this.model).subscribe();
  }

  /* Method for updating particular test */
  updateTest()
  {
    this.router.navigate(['/updatetests'])
  }

  ngOnInit() {
  }

}
