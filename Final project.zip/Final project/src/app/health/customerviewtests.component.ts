import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-customerviewtests',
  templateUrl: './customerviewtests.component.html',
  styleUrls: ['./customerviewtests.component.css']
})
export class CustomerviewtestsComponent implements OnInit {
data:any=[];
data1:any={};
mobile:string;
technician:any={};
disabled:boolean=true;

message:boolean=false;
cost:any;
  constructor(private service:HealthService,private router:Router) {
   
   }
  result:any=[];
  result1:any;

  /* Method for adding new tests */
  AddTests(event,price,testname){
    alert(testname+ " was booked");
    console.log(event);
  this.disabled=false;
  this.message=true;
  console.log("this"+this.disabled);
  console.log("price is"+price);
  let mail=localStorage.getItem("mail");
  console.log("cust mail in "+mail);
  this.service.getPrice(mail,price).subscribe(price=>{
    this.cost=price;
    console.log("total bill is"+this.cost);
  })
  
  


}
next(){

  this.router.navigate(['/customeroperations'])
}
/* method for status of customer */
status(){
  this.service.acceptOrReject();
}
/* method for logout */

Logout(){
  let mail=localStorage.getItem("mail");
  console.log("cust mail in logout"+mail);
  this.service.setTotalPricetoZero(mail).subscribe();
  this.router.navigate(['/home'])
}
history(){
  
  let mobile=localStorage.getItem("mobile")
  console.log(mobile);
 this.service.gettechnicianById(mobile).subscribe(result1=>{this.data1=result1
 console.log(this.data1.technicianName);
this.technician=this.data1;
console.log("initially"+this.technician)
 });
 console.log("Finally"+this.technician)
}
  ngOnInit() {
    this.service.getAllTests().subscribe(result=>this.data=result);
    

  }

}
