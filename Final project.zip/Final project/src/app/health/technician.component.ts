import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technician',
  templateUrl: './technician.component.html',
  styleUrls: ['./technician.component.css']
})
export class TechnicianComponent implements OnInit {
mobile:number;
password:any;
email:any;
result:any;
message:boolean=false;
pass:string;
  constructor(private service:HealthService,private router:Router) { }

  /* method for checking the login credentials of technician */
  check(mobile,password,email){
    this.pass=btoa(this.password);
    this.service.getTechnicianDetails(mobile,this.pass).subscribe(data=>{
      this.result=data;
      if(this.result==true)
      {
        console.log("technician mail is "+email);
        this.service.technicianMail=email;
        localStorage.setItem("mobile",mobile);
        console.log("Current technician is "+this.service.technicianMail);
        console.log("current user is"+this.service.currentUser);
        this.router.navigate(['/technicianacceptreject'])
      }
     
      else {
        this.message=true;
      }

    });
  }


  
  ngOnInit() {
  }

}
