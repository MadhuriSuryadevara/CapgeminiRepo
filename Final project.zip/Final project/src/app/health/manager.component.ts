import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {
mobile:number;
password:any;
email:any;
result:any;
data:any;
pwd:string;
message:boolean=false;
  constructor(private service:HealthService,private router:Router) { }
  /* Method for checking correct credentials of manager */
  check(mobile,password){
    this.pwd=btoa(password);
    localStorage.setItem("mmobile",mobile);
    console.log("mobile and password is"+mobile+password)
    this.service.getAllRoleDetails(mobile,password).subscribe(data=>{
      this.result=data;
      if(this.result==1)
      {
        this.router.navigate(['/manageroperations'])
      }
     
      else {
        this.message=true;
      }

    });
  }

  ngOnInit() {

  }

}
