import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
model:any={}
result:boolean=false;
pass:string;
/* method for adding new user */
addUser():any{
  this.result=true;
  this.pass=btoa(this.model.password);
  console.log("pwd is"+this.pass);
  this.model.password=this.pass;
  this.service.addUserRegister(this.model).subscribe();
}
back(){
this.router.navigate(['/home'])
}
  ngOnInit() {
  }

}
