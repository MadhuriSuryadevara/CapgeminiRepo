import { Component, OnInit } from '@angular/core';
import { FoodService } from './food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminaddrecipe',
  templateUrl: './adminaddrecipe.component.html',
  styleUrls: ['./adminaddrecipe.component.css']
})
export class AdminaddrecipeComponent implements OnInit {
  model:any={}
  result:boolean=false;

  constructor(private service:FoodService,private router:Router) { }
  addRecipe()
  {
    this.result=true
    this.service.addRecipe(this.model).subscribe();
  }

  ngOnInit() {
  }


}
