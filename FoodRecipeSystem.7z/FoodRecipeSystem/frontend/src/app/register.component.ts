import { Component, OnInit } from '@angular/core';
import { FoodService } from './food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  constructor(private service:FoodService,private router:Router) { }
  result:boolean=false;
  model:any={}
  onSubmit(model):any
  {
    this.result=true;
    this.service.addUserRegister(this.model).subscribe((data)=>{

    })

  }
  back()
  {
    this.router.navigate(['/home']);
  }

  ngOnInit() {
  }


}
