import { Component, OnInit } from '@angular/core';
import { FoodService } from './food.service';

@Component({
  selector: 'app-usersave',
  templateUrl: './usersave.component.html',
  styleUrls: ['./usersave.component.css']
})
export class UsersaveComponent implements OnInit {
  data:any=[];

  constructor(private service:FoodService) { }

  ngOnInit() {
    this.service.getByRecipeId(localStorage.getItem("userMobile")).subscribe(result=>{this.data=result});
  }

}
