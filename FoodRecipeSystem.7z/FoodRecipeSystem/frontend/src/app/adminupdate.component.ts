import { Component, OnInit } from '@angular/core';
import { FoodService } from './food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminupdate',
  templateUrl: './adminupdate.component.html',
  styleUrls: ['./adminupdate.component.css']
})
export class AdminupdateComponent implements OnInit {
  recipeId:number;
  recipeIngridents:String
  show:boolean=false;

  constructor(private service:FoodService,private router:Router) { }
  updateItem()
  {
    this.show=true;
    this.service.updateRecipe(this.recipeId,this.recipeIngridents).subscribe()
  }
  back()
  {
    this.router.navigate(['/adminoperations']);
  }

  ngOnInit() {
    this.recipeId=this.service.currentitemid;
    console.log("item id"+this.recipeId);
  }

}
