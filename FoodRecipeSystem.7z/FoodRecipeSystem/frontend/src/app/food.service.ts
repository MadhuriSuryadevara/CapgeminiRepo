import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class FoodService {
  currentitemid:number=0;

  constructor(private http:HttpClient) { }
  addUserRegister(data:any)
  {
    let userinput={
      "mobileNumber":data.mobile,
      "name":data.username,
      "email":data.email,
      "password":data.password

    }
    return this.http.post("http://localhost:9234/register/adduser",userinput)
  }
  userLogin(mobile:number,password:string)
  {
    return this.http.get("http://localhost:9234/register/validateCtredentials/"+mobile+"/"+password);
  }
  adminLogin(mobile:number,password:string)
  {
    return this.http.get("http://localhost:9234/admin/validateCtredentials/"+mobile+"/"+password)
  }
  getAllRecipe(){
    return this.http.get("http://localhost:9234/admin/getAllRecipe");
  }
  deleteRecipe(recipeId:any)
  {
    return this.http.delete("http://localhost:9234/admin/deleterecipe/"+recipeId);
  }
  updateRecipe(recipeId:number,recipeIngridents:String){
    return this.http.put("http://localhost:9234/admin/updaterecipe/"+recipeId+"/"+recipeIngridents,recipeId);
  }
  addRecipe(data:any)
  {
    let recipeinput={
      "recipeId":data.recipeid,
      "recipeName":data.recipeName,
      "recipeIngridents":data.recipeIngridents,
      "recipeProcess":data.recipeDescription
    }
    return this.http.post("http://localhost:9234/admin/addRecipe/",recipeinput)
  }
  getByRecipeId(recipeId)
  {
    return this.http.get("http://localhost:9234/admin/getbyid/"+recipeId);
  }
  setRecipelist(mobile,id){
    return this.http.get("http://localhost:9234/admin/setrecipelist/"+mobile+"/"+id);
  }

}
