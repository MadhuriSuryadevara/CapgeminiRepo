import { Component, OnInit } from '@angular/core';
import { FoodService } from './food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  data1:any;
  result:any;
  data:any;

  constructor(private service:FoodService,private router:Router) { }
  onSubmit(userForm)
  {
    console.log("check admin"+userForm.role);
      if(userForm.role=="admin")
      {
        this.service.adminLogin(userForm.mobile,userForm.password).subscribe(result=>{this.data1=result
        console.log("check admin"+this.data1);
          if(this.data1==true){
          this.router.navigate(['/adminoperations'])
        }
        else{
          alert("you are not a admin")
        }
        })
      }
      else{
        this.service.userLogin(userForm.mobile,userForm.password).subscribe(result=>{
          this.data=result;
          if(this.data==true){
            localStorage.setItem("userMobile",userForm.mobile);
            this.router.navigate(['/useroperations'])
          }
          else{
            alert("enter correct credentials")
          }
        })
      }

  }


  ngOnInit() {
  }

}
