import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home.component';
import { RegisterComponent } from './register.component';
import { LoginComponent } from './login.component';
import { AdminoperationsComponent } from './adminoperations.component';
import { UseroperationsComponent } from './useroperations.component';
import { AdminupdateComponent } from './adminupdate.component';
import { AdminaddrecipeComponent } from './adminaddrecipe.component';
import { UsersaveComponent } from './usersave.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'adminoperations',component:AdminoperationsComponent},
  {path:'useroperations',component:UseroperationsComponent},
  {path:'adminupdate',component:AdminupdateComponent},
  {path:'adminaddrecipe',component:AdminaddrecipeComponent},
  {path:'usersave',component:UsersaveComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
