import { Component, OnInit } from '@angular/core';
import { FoodService } from './food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-useroperations',
  templateUrl: './useroperations.component.html',
  styleUrls: ['./useroperations.component.css']
})
export class UseroperationsComponent implements OnInit {
  data:any;
  data1:any;

  constructor(private service:FoodService,private router:Router) { }
  savedrecipes()
  {
    this.router.navigate(['/usersave']);
  }
  save(recipeId)
  {
    localStorage.setItem("recipeId",recipeId);
    this.service.setRecipelist(localStorage.getItem("userMobile"),recipeId).subscribe(result=>{
      this.data1=result;
    if(this.data1==1)
    alert("recipe saved");
    })
  }

  ngOnInit() {
    this.service.getAllRecipe().subscribe(result=>{
      this.data=result})

  }

}
