import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FoodService } from './food.service';

@Component({
  selector: 'app-adminoperations',
  templateUrl: './adminoperations.component.html',
  styleUrls: ['./adminoperations.component.css']
})
export class AdminoperationsComponent implements OnInit {
result:any=[];
data:any=[];
show:boolean=false;
  constructor(private router:Router,private service:FoodService) { }
  Logout(){
    this.router.navigate(['/home'])

  }
  deleteRecipe(recipeId:any)
  {
    let index=this.data.indexOf(recipeId);
  this.data.splice(index,1);  
  window.location.reload();
    this.service.deleteRecipe(recipeId).subscribe();
  }
  updateRecipe(recipeId)
  {
    this.service.currentitemid=recipeId;
    console.log("recipe id is"+this.service.currentitemid);
    this.router.navigate((['/adminupdate']))
  }
  addRecipe()
  {
    this.show=true;
    this.router.navigate(['/adminaddrecipe'])
  }



  ngOnInit() {
    this.service.getAllRecipe().subscribe(result=>{
      this.data=result})
  }

}
