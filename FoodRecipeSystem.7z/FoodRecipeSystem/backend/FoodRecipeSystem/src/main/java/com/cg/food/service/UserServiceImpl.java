package com.cg.food.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.food.dao.IuserDao;
import com.cg.food.dto.User;

@Service
public class UserServiceImpl implements IuserService {
	@Autowired
	IuserDao iuserdao;

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return iuserdao.addUser(user);
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return iuserdao.getAllUsers();
	}

	@Override
	public boolean validateLogin(Long mobileNumer, String password) {
		// TODO Auto-generated method stub
		return iuserdao.validateLogin(mobileNumer, password);
	}
	

}
