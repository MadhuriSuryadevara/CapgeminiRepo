package com.cg.food.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.food.dao.IadminDao;
import com.cg.food.dto.Admin;
import com.cg.food.dto.Recipe;
@Service
public class AdminServiceImpl implements IAdminService {
		@Autowired
		IadminDao iadmindao;
		
	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return iadmindao.addAdmin(admin);
	}

	@Override
	public boolean validateLogin(Long mobileNumber, String password) {
		// TODO Auto-generated method stub
		return iadmindao.checkAdminCredentials(mobileNumber, password);
	}

	@Override
	public Recipe addRecipe(Recipe recipe) {
		// TODO Auto-generated method stub
		return iadmindao.addRecipe(recipe);
	}

	@Override
	public List<Recipe> getAllRecipe() {
		// TODO Auto-generated method stub
		return iadmindao.getAllRecipe();
	}

	@Override
	public void updateRecipe(Integer recipeId,String recipeIngridents) {
		// TODO Auto-generated method stub
		iadmindao.updateRecipe(recipeId, recipeIngridents);
		
	}

	@Override
	public void deleteRecipe(Integer recipeId) {
		// TODO Auto-generated method stub
		iadmindao.deleteRecipe(recipeId);
		
		
	}

	@Override
	public List<Recipe> getRecipeList(Long mobile) {
		// TODO Auto-generated method stub
		return iadmindao.getRecipeList(mobile);
	}

	@Override
	public Integer setRecipeList(Long mobile, Integer recipeid) {
		// TODO Auto-generated method stub
		return iadmindao.setRecipeList(mobile, recipeid);
	}

}
