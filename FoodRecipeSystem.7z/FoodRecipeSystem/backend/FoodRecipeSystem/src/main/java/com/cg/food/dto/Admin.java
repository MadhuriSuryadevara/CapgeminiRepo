package com.cg.food.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="admin")
public class Admin {
	private Long mobileNumber;
	private String email;;
	private String password;
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Admin(Long mobileNumber, String email, String password) {
		super();
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.password = password;
	}
	public Admin() {
		
	}
	@Override
	public String toString() {
		return "Admin [mobileNumber=" + mobileNumber + ", email=" + email + ", password=" + password + "]";
	}
	
	
	
	

}
