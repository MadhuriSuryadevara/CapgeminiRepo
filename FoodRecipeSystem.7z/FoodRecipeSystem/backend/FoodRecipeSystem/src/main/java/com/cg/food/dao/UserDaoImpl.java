package com.cg.food.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.food.dto.Recipe;
import com.cg.food.dto.User;

@Repository
public class UserDaoImpl implements IuserDao {
@Autowired
MongoTemplate mongotemplate;

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(user);
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(User.class);
	}

	@Override
	public boolean validateLogin(Long mobileNumber, String password) {
		// TODO Auto-generated method stub
		boolean flag=false;
		List<User> userdetails=mongotemplate.findAll(User.class);
		for(User user1:userdetails)
		{
			if(user1.getMobileNumber().equals(mobileNumber)){
				if(user1.getPassword().equals(password)) {
					flag=true;
					return flag;
				}
			}
		}
		
		return flag;
	}

	

}
