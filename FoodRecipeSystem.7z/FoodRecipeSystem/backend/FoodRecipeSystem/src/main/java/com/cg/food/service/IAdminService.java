package com.cg.food.service;

import java.util.List;

import com.cg.food.dto.Admin;
import com.cg.food.dto.Recipe;

public interface IAdminService {
	public Admin addAdmin(Admin admin);
	public boolean validateLogin(Long mobileNumer,String password);
	public Recipe addRecipe(Recipe recipe);
	public List<Recipe> getAllRecipe();
	public void updateRecipe(Integer recipeId,String recipeIngridents);
	public void deleteRecipe(Integer recipeId);
	public Integer setRecipeList(Long mobile,Integer recipeid);

	List<Recipe> getRecipeList(Long mobile);

}
