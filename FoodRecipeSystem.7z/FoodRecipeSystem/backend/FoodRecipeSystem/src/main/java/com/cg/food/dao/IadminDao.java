package com.cg.food.dao;

import java.util.List;

import com.cg.food.dto.Admin;
import com.cg.food.dto.Recipe;

public interface IadminDao {
	public Admin addAdmin(Admin admin);
	public boolean checkAdminCredentials(Long mobileNumber, String password);
	public Recipe addRecipe(Recipe recipe);
	public List<Recipe> getAllRecipe();
	public void updateRecipe(Integer recipeId,String recipeIngridents);
	public void deleteRecipe(Integer recipeId);
	
	List<Recipe> getRecipeList(Long mobile);
	public Integer setRecipeList(Long mobile,Integer recipeid);


}
