package com.cg.food.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.food.dto.Admin;
import com.cg.food.dto.Recipe;
import com.cg.food.dto.User;
@Repository
public class AdminDaoImpl implements IadminDao{
		@Autowired
		MongoTemplate mongotemplate;
	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(admin);
	}
	@Override
	public boolean checkAdminCredentials(Long mobileNumber, String password) {
		// TODO Auto-generated method stub
		boolean flag=false;
		List<Admin> admindetails=mongotemplate.findAll(Admin.class);
		for(Admin admin1:admindetails)
		{
			if(admin1.getMobileNumber().equals(mobileNumber)){
				if(admin1.getPassword().equals(password)) {
					flag=true;
					return flag;
					
				}
			}
		}
		
		return flag;
	}
	@Override
	public Recipe addRecipe(Recipe recipe) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(recipe);
	}
	@Override
	public List<Recipe> getAllRecipe() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(Recipe.class);
	}
	@Override
	public void updateRecipe(Integer recipeId,String recipeIngridents) {
		// TODO Auto-generated method stub
		List<Recipe> recipedetails=mongotemplate.findAll(Recipe.class);
		for(Recipe recipe1:recipedetails) {
			if(recipe1.getRecipeId().equals(recipeId)) {
				recipe1.setRecipeIngridents(recipeIngridents);
				mongotemplate.save(recipe1);
			}
		}
		
	}
	@Override
	public void deleteRecipe(Integer recipeId) {
		// TODO Auto-generated method stub
		List<Recipe> recipes=mongotemplate.findAll(Recipe.class);
		for(Recipe recipedetails:recipes) {
			if(recipedetails.getRecipeId().equals(recipeId)) {
				mongotemplate.remove(recipedetails);
		
	}
	

}
	}
	@Override
	public List<Recipe> getRecipeList(Long mobile) {
		// TODO Auto-generated method stub
		User user=mongotemplate.findOne(Query.query(Criteria.where("mobileNumber").is(mobile)), User.class);
		List<Integer> recipeList=user.getRecipeId();
		List<Recipe> itemsList=new ArrayList<>();
		for (Integer i : recipeList) {
			Recipe recipe=mongotemplate.findOne(Query.query(Criteria.where("recipeId").is(i)), Recipe.class);
			itemsList.add(recipe);
			
		}
		
		return itemsList;
		
	}
	@Override
	public Integer setRecipeList(Long mobile, Integer recipeid) {
		// TODO Auto-generated method stub
		User user=mongotemplate.findOne(Query.query(Criteria.where("mobileNumber").is(mobile)), User.class);
		List<Integer> recipeList=user.getRecipeId();
		List<Integer> itemsList=new ArrayList<>();

		if(recipeList!=null) {
			
			recipeList.add(recipeid);
			user.setRecipeId(recipeList);
			
		
		}
		else {
			
			itemsList.add(recipeid);
			user.setRecipeId(itemsList);
		}
		mongotemplate.save(user);
		
		return 1;
	}
	
	
}
