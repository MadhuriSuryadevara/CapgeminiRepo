package com.cg.food.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.food.dto.User;
import com.cg.food.service.IuserService;

@RestController
@RequestMapping("/register")
@CrossOrigin(origins="http://localhost:4200")
public class UserController {
	
	@Autowired
	IuserService iuserservice;
	
	@PostMapping("/adduser")
	public User addUser(@RequestBody User user)
	{
		System.out.println("in controller");
	    return iuserservice.addUser(user);
	}
	@GetMapping("/getallusers")
	public List<User> getAllUsers()
	{
		return iuserservice.getAllUsers();
	}
	
	@GetMapping("/validateCtredentials/{mobile}/{password}")
	public boolean validateCredentials(@PathVariable("mobile") Long mobileNumber,@PathVariable("password") String password)
	{
		return iuserservice.validateLogin(mobileNumber, password);
}
}