package com.cg.food.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.food.dto.Admin;
import com.cg.food.dto.Recipe;
import com.cg.food.service.IAdminService;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins="http://localhost:4200")
public class AdminController {
	@Autowired
	IAdminService iadminservice;
	@PostMapping("/addadmin")
	public Admin addAdmin(@RequestBody Admin admin)
	{
		return iadminservice.addAdmin(admin);
	}
	@GetMapping("/validateCtredentials/{mobile}/{password}")
	public boolean validateCredentials(@PathVariable("mobile") Long mobileNumber,@PathVariable("password") String password)
	{
		return iadminservice.validateLogin(mobileNumber, password);
	
	}
	@PostMapping("/addRecipe")
	public Recipe addRecipe(@RequestBody Recipe recipe)
	{
		return iadminservice.addRecipe(recipe);
	}
	@GetMapping("/getAllRecipe")
	public List<Recipe> getAllRecipe()
	{
		return iadminservice.getAllRecipe();
	}
	@PutMapping("/updaterecipe/{recipeId}/{recipeIngridents}")
	 public void updateRecipe(@PathVariable("recipeId") Integer recipeId,@PathVariable("recipeIngridents") String recipeIngridents){
		iadminservice.updateRecipe(recipeId, recipeIngridents);
		 
	 }
	@DeleteMapping("/deleterecipe/{id}")
	public void deleteRecipe(@PathVariable("id") Integer recipeId) {
		System.out.println("in delete");
		iadminservice.deleteRecipe(recipeId);
	}
	@GetMapping("/getbyid/{mobile}")
	public List<Recipe> getRecipeList(@PathVariable("mobile") Long mobile)
	{
		return iadminservice.getRecipeList(mobile);
	}
	@GetMapping("setrecipelist/{mobile}/{id}")
	public Integer setRecipeList(@PathVariable("mobile") Long mobile,@PathVariable("id") Integer id) {
		return iadminservice.setRecipeList(mobile, id);
	}
	
	
}
