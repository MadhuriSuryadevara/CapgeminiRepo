package com.cg.food.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="recipe")

public class Recipe {
	@Id
	private Integer recipeId;
	private String recipeName;
	private String recipeIngridents;
	private String recipeProcess;
	private String recipeCategory;
	public String getRecipeCategory() {
		return recipeCategory;
	}
	public void setRecipeCategory(String recipeCategory) {
		this.recipeCategory = recipeCategory;
	}
	public Integer getRecipeId() {
		return recipeId;
	}
	public void setRecipeId(Integer recipeId) {
		this.recipeId = recipeId;
	}
	public String getRecipeName() {
		return recipeName;
	}
	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}
	public String getRecipeIngridents() {
		return recipeIngridents;
	}
	public void setRecipeIngridents(String recipeIngridents) {
		this.recipeIngridents = recipeIngridents;
	}
	public String getRecipeProcess() {
		return recipeProcess;
	}
	public void setRecipeProcess(String recipeProcess) {
		this.recipeProcess = recipeProcess;
	}
	public Recipe(Integer recipeId, String recipeName, String recipeIngridents, String recipeProcess,
			String recipeCategory) {
		super();
		this.recipeId = recipeId;
		this.recipeName = recipeName;
		this.recipeIngridents = recipeIngridents;
		this.recipeProcess = recipeProcess;
		this.recipeCategory = recipeCategory;
	}
	public Recipe() {
		
	}
	@Override
	public String toString() {
		return "Recipe [recipeId=" + recipeId + ", recipeName=" + recipeName + ", recipeIngridents=" + recipeIngridents
				+ ", recipeProcess=" + recipeProcess + ", recipeCategory=" + recipeCategory + "]";
	}
	
	
	

}
