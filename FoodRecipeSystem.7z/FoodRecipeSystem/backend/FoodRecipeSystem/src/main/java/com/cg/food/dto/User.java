package com.cg.food.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="register")
public class User {

	@Id
	private Long mobileNumber;
	private String name;
	private String email;
	private String password;
	private List<Integer> recipeId;
	
	public List<Integer> getRecipeId() {
		return recipeId;
	}
	public void setRecipeId(List<Integer> recipeId) {
		this.recipeId = recipeId;
	}
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public User(Long mobileNumber, String name, String email, String password, List<Integer> recipeId) {
		super();
		this.mobileNumber = mobileNumber;
		this.name = name;
		this.email = email;
		this.password = password;
		this.recipeId = recipeId;
	}
	@Override
	public String toString() {
		return "User [mobileNumber=" + mobileNumber + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", recipeId=" + recipeId + "]";
	}
	

}
