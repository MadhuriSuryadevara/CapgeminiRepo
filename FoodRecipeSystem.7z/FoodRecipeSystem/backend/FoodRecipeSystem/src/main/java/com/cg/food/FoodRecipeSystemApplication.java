package com.cg.food;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodRecipeSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodRecipeSystemApplication.class, args);
		System.out.println("in spring main");
	}

}
