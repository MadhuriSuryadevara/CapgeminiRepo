package com.cg.food.dao;



import java.util.List;

import com.cg.food.dto.User;

public interface IuserDao {
	public User addUser(User user);
	public List<User> getAllUsers();
	public boolean validateLogin(Long mobileNumer,String password);
	
	

}
